# Installation

Install it via composer:

```
composer require konekt/enum
```

**Next**: [Upgrade &raquo;](upgrade.md)
