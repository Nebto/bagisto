# Enum <small>3.0</small>

> As of Release v3.0, the Documentation has been moved to:

- [Enum Documentation 3.0](https://konekt.dev/enum/3.0)
- [Enum Documentation 2.2](https://konekt.dev/enum/2.2)
- [Documentation here is also still available](#konekt-enum-documentation)
