<?php
/**
 * Contains the Sample1234 class.
 *
 * @copyright   Copyright (c) 2017 Attila Fulop
 * @author      Attila Fulop
 * @license     MIT
 * @since       2017-09-07
 *
 */

namespace Konekt\Enum\Tests\Fixture;

class Sample1234 extends Sample123
{
    public const FOUR = 4;
}
